import type { AgentInput } from '../../agent/define/session/types.ts'
import type { Message } from '../../message/index.ts'
import type { AgentRunEvent } from '../../agent/mode/run-agent.ts'
import type { CompactionResult } from '../../agent/memory/compaction.ts'
import type { AgentCompactionOptions } from '../../agent/memory/compaction-config.ts'
import type { AgentSessionSnapshot } from '../../agent/define/session/types.ts'
import type { ApprovalBroker, ApprovalRequest } from '../../agent/tool/approval.ts'
import type { ToolDefinition } from '../../agent/tool/definition.ts'
import type { ToolInterceptor } from '../../agent/tool/pipeline.ts'
import type { ContextSection } from '../../agent/context/types.ts'
import type { TurnHooks } from '../../agent/loop/types.ts'
import type { UserInputBroker, UserInputDecision, UserInputRequest } from '../../agent/mode/user-input.ts'
import type { UsagePolicy } from '../../agent/accounting/report.ts'
import type { ModelModality, ModelOutputFormat, NativeToolSchema, ToolChoice } from '../../contract/index.ts'
import type { JsonValue } from '../../primitives/index.ts'
import type { ModelTarget } from '../provider/types.ts'
import type { RuntimeRunReport } from '../observation/final-report.ts'
import type { ToolSource } from '../tool-source/types.ts'
import type { SpillStore } from '../../agent/tool/output-budget.ts'
import type { MemoryBinding } from '../memory/types.ts'
import type { RuntimeSkillSource } from '../skill-provider/types.ts'
import type { AgentRuntimeLimits, AgentRunEventBufferLimits } from '../../agent/define/session/types.ts'
import type { HistoryLimits } from '../../agent/history/types.ts'
import type { RunLedgerLimits } from '../../agent/accounting/report.ts'

export interface RuntimeAgentDefinitionInput {
  readonly id: string
  readonly name?: string
  readonly description?: string
  readonly model: ModelTarget
  readonly instructions: string
  readonly effort?: string
  readonly maxTokens?: number
  /** Overrides the model/route/runtime-defaults tiers, same precedence as `maxTokens`. */
  readonly contextWindow?: number
  /** Overrides the model/route/runtime-defaults tiers, same precedence as `maxTokens`. */
  readonly inputModalities?: readonly ModelModality[]
  readonly mode?: 'basic' | 'deep' | 'deep-human-in-loop'
  readonly tools?: readonly ToolDefinition[]
  readonly nativeTools?: readonly NativeToolSchema[]
  readonly toolChoice?: ToolChoice
  readonly outputFormat?: ModelOutputFormat
  readonly toolSources?: readonly ToolSource[]
  readonly skills?: readonly RuntimeSkillSource[]
  readonly allowedSkillIds?: readonly string[]
  readonly memory?: MemoryBinding
  /**
   * Model-visible context this agent always recomputes before a model round.
   *
   * Definition-level sections belong to the agent wherever it runs; mount an
   * environment-dependent one (project instruction files, working-tree state)
   * on the session instead.
   */
  readonly contextSections?: readonly ContextSection[]
  readonly compaction?: AgentCompactionOptions | false
  /** Model steps per prompt; 'auto' removes the step ceiling, not resource limits. */
  readonly maxTurns?: number | 'auto'
  readonly maxToolCalls?: number
  readonly commentary?: 'auto' | 'concise' | 'off'
  /** Extra headers/body fields for this agent's provider requests; this agent's value wins where it collides with the route's own. */
  readonly providerOptions?: {
    readonly headers?: Readonly<Record<string, string>>
    readonly body?: Readonly<Record<string, unknown>>
  }
}

export interface RuntimeAgentDefinition extends RuntimeAgentDefinitionInput {}

export interface RuntimeAgentBindingInput extends Omit<RuntimeAgentDefinitionInput, 'model'> {
  readonly model?: { readonly provider: string; readonly id?: string }
}

export interface RuntimeAgentLimits extends AgentRuntimeLimits {
  readonly maxSteps?: number | 'auto'
  readonly maxToolCalls?: number
}

export interface RuntimeAgentSessionOptions {
  readonly conversationId?: string
  readonly tools?: readonly ToolDefinition[]
  readonly toolSources?: readonly ToolSource[]
  readonly skills?: readonly RuntimeSkillSource[]
  readonly memory?: MemoryBinding | false
  readonly skillCwd?: string
  readonly userInput?: UserInputBroker
  readonly approvals?: ApprovalBroker
  /**
   * Where oversized tool output is saved instead of being cut.
   *
   * Mounting one makes the default `auto` overflow policy spill rather than
   * truncate, and gives the model `read_tool_output` to read the rest back.
   */
  readonly spillStore?: SpillStore
  readonly interceptors?: readonly ToolInterceptor[]
  /**
   * Model-visible context recomputed before every model round.
   *
   * Mount a platform package's section (project instruction files, working-tree
   * state) here; the core never reads a file to build one.
   */
  readonly contextSections?: readonly ContextSection[]
  readonly hooks?: TurnHooks
  readonly usagePolicy?: UsagePolicy
  /** In-memory append-only conversation history limits. */
  readonly historyLimits?: HistoryLimits
  /** Canonical per-run accounting ledger limits. */
  readonly ledgerLimits?: RunLedgerLimits
  /** Public run-event queue limits for slow or paused consumers. */
  readonly eventBufferLimits?: AgentRunEventBufferLimits
  readonly runtimeLimits?: RuntimeAgentLimits
  readonly compaction?: AgentCompactionOptions | false
}

export interface RuntimeAgentInvocationOptions {
  /**
   * Model for THIS invocation only.
   *
   * The agent's bound target is unchanged — `agent.model` still reports it, and
   * the next call without an override uses it again — so one session can put
   * successive turns on different models without becoming a different agent.
   * Resolved against the same configured routes as the binding, with the same
   * failures (`MODEL_ROUTE_UNKNOWN`, `MODEL_DEFAULT_MISSING`), and resolved
   * before the run acquires anything, so a bad target costs no I/O. Route-only
   * (`{ provider }`) takes that route's configured default model.
   *
   * The target is frozen for the run it starts: every step of that turn reaches
   * the same model. There is deliberately no fallback to another model when the
   * chosen one fails — the failure is raised to the caller.
   */
  readonly model?: { readonly provider: string; readonly id?: string }
  /** Output ceiling for this invocation only; dropped, like effort, on a model switch. */
  readonly maxTokens?: number
  /** One schema adapter supplies the provider schema and a synchronous runtime validator. */
  readonly structuredOutput?: {
    readonly name: string
    readonly schema: import('../../agent/tool/schema.ts').RuntimeSchema<JsonValue>
  }
  /** strict rejects known text-only models when request history contains images; project permits lossy conversion. */
  readonly imagePolicy?: 'strict' | 'project'
  /** strict rejects models that decline document input when history contains documents; project permits lossy conversion. */
  readonly documentPolicy?: 'strict' | 'project'
  readonly signal?: AbortSignal
  readonly additionalInstructions?: string
  /** Include raw span lifecycle events in the public stream for host tracing. */
  readonly includeTraceEvents?: boolean
  readonly onEvent?: (event: RuntimeAgentRunEvent) => void | Promise<void>
}

export interface RuntimeAgentRunEventContext {
  readonly schemaVersion: 1
  readonly runId: string
  readonly traceId: string
  readonly sequence: number
}

type PublicContentEvent = AgentRunEvent extends infer E
  ? E extends { type: 'text-end' | 'image-delta' | 'assistant-message' | 'compaction-start' | 'compaction-end' | 'turn-start' | 'step-start' | 'step-end' | 'assistant-text' | 'assistant-reasoning' | 'reasoning-delta' }
    ? Omit<E, 'trace'> & { readonly blockId?: string } : never
  : never

type PublicTraceEvent = Extract<AgentRunEvent, { type: 'span-start' | 'span-end' }>

export type RuntimeAgentRunEvent = RuntimeAgentRunEventContext & (
  | PublicContentEvent
  | PublicTraceEvent
  | { readonly type: 'commentary-delta'; readonly text: string; readonly index: number; readonly blockId: string; readonly phase: import('../../agent/loop/events.ts').StreamedAssistantTextPhase }
  | { readonly type: 'assistant-delta'; readonly text: string; readonly index: number; readonly blockId: string; readonly phase: import('../../agent/loop/events.ts').StreamedAssistantTextPhase }
  | { readonly type: 'tool-call'; readonly callId: string; readonly name: string; readonly input: unknown }
  | { readonly type: 'tool-result'; readonly callId: string; readonly name: string;
      readonly status: 'completed' | 'failed' | 'aborted' | 'rejected' | 'declined';
      readonly output: unknown }
  | { readonly type: 'assistant-native-tool'; readonly callId: string; readonly provider: string;
      readonly name: string; readonly status: 'started' | 'completed' | 'failed' | 'unknown';
      readonly input?: JsonValue; readonly output?: JsonValue }
  | { readonly type: 'approval-request'; readonly request: ApprovalRequest }
  | { readonly type: 'user-input-request'; readonly request: UserInputRequest }
  | { readonly type: 'user-input-response'; readonly requestId: string; readonly response: UserInputDecision }
  | { readonly type: 'usage'; readonly usage: RuntimeRunReport['usage']; readonly report: RuntimeRunReport }
  | { readonly type: 'usage-progress'; readonly usage: import('../../observation/usage.ts').UsageCounters; readonly attemptId?: string }
  | { readonly type: 'error'; readonly error: RuntimeRunReport['errors'][number]; readonly report: RuntimeRunReport }
)

export interface RuntimeAgentResponse {
  /** Objective completion, independent of report.status (execution status). */
  readonly completed: boolean
  /** Terminal control-flow reason; deep mode can stop without an accepted submission. */
  readonly stopReason: import('../../agent/loop/types.ts').TurnEndReason['kind']
  readonly runId: string
  readonly traceId: string
  readonly text: string
  readonly output?: JsonValue
  readonly message?: Message
  readonly usage: RuntimeRunReport['usage']
  readonly report: RuntimeRunReport
}

export interface RuntimeAgentRunHandle extends AsyncIterable<RuntimeAgentRunEvent> {
  readonly runId: string
  /** Settles after run cleanup; the session can be reused unless it or its runtime is closed. */
  readonly result: Promise<RuntimeAgentResponse>
  readonly report: Promise<RuntimeRunReport>
  abort(reason?: unknown): void
}

export interface RuntimeAgentSessionSnapshot extends AgentSessionSnapshot {
  readonly memoryBindingId?: string
}

export interface RuntimeAgentSession {
  readonly conversationId: string
  readonly isRunning: boolean
  run(input: AgentInput, options?: RuntimeAgentInvocationOptions): Promise<RuntimeAgentResponse>
  stream(input: AgentInput, options?: RuntimeAgentInvocationOptions): RuntimeAgentRunHandle
  inject(input: AgentInput): number
  snapshot(): RuntimeAgentSessionSnapshot
  compact(options?: RuntimeAgentInvocationOptions): Promise<CompactionResult | null>
  reset(): void
  whenIdle(signal?: AbortSignal): Promise<void>
}

export interface RuntimeAgent {
  readonly model: ModelTarget
  generate(input: AgentInput, options?: RuntimeAgentInvocationOptions): Promise<RuntimeAgentResponse>
  stream(input: AgentInput, options?: RuntimeAgentInvocationOptions): RuntimeAgentRunHandle
  createSession(options?: RuntimeAgentSessionOptions): RuntimeAgentSession
  resumeSession(snapshot: RuntimeAgentSessionSnapshot, options?: RuntimeAgentSessionOptions): RuntimeAgentSession
}

export type LegacyAgentEvent = AgentRunEvent
