import { spawn, spawnSync, type ChildProcess } from 'node:child_process'
import { createServer } from 'node:http'
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { extname, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import { chromium } from 'playwright'

const packageRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
const workspaceRoot = resolve(packageRoot, '../..')
const artifacts = join(packageRoot, 'artifacts')
rmSync(artifacts, { recursive: true, force: true })
mkdirSync(artifacts, { recursive: true })

const coreTarball = pack(join(workspaceRoot, 'packages', 'core'), artifacts)
const serverTarball = pack(packageRoot, artifacts)
const temporaryRoot = mkdtempSync(join(tmpdir(), 'ai-agent-sdk-mcp-server-pack-'))
try {
  const consumers = new Map<string, string>()
  for (const runtime of ['standards', 'browser', 'worker', 'types']) {
    const consumer = join(temporaryRoot, runtime)
    cpSync(join(packageRoot, 'fixtures', runtime), consumer, { recursive: true })
    cpSync(join(packageRoot, 'fixtures', 'shared', 'smoke.mjs'), join(consumer, 'fixture.mjs'))
    run('npm', [
      'install', '--ignore-scripts', '--no-package-lock', '--no-audit', '--no-fund',
      coreTarball, serverTarball,
    ], consumer)
    consumers.set(runtime, consumer)
  }
  run(process.execPath, ['smoke.mjs'], required(consumers, 'standards'))
  run(process.execPath, [join(workspaceRoot, 'node_modules', 'typescript', 'bin', 'tsc'), '-p', 'tsconfig.json'],
    required(consumers, 'types'))
  await testBrowser(required(consumers, 'browser'))
  await testWorker(required(consumers, 'worker'))
  process.stdout.write(`packed MCP server runtime matrix passed: ${relative(workspaceRoot, serverTarball)}\n`)
} finally {
  rmSync(temporaryRoot, { recursive: true, force: true })
}

function pack(root: string, destination: string): string {
  const output = run('npm', [
    'exec', '--yes', '--package=pnpm@11.25.0', '--',
    'pnpm', 'pack', '--pack-destination', destination,
  ], root)
  const tarball = output.split(/\r?\n/).map(line => line.trim()).findLast(line => line.endsWith('.tgz'))
  if (!tarball) throw new Error(`pnpm pack did not report a tarball for ${root}`)
  return resolve(root, tarball)
}

function required(values: ReadonlyMap<string, string>, key: string): string {
  const value = values.get(key)
  if (!value) throw new Error(`missing ${key} fixture`)
  return value
}

function run(command: string, args: readonly string[], cwd: string): string {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8', env: process.env })
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed\n${result.stdout}\n${result.stderr}`)
  return result.stdout
}

async function testBrowser(consumer: string): Promise<void> {
  const missing: string[] = []
  const server = createServer((request, response) => {
    const url = new URL(request.url ?? '/', 'http://127.0.0.1')
    const requested = url.pathname === '/' ? '/index.html' : url.pathname
    let target = resolve(consumer, `.${requested}`)
    if (!existsSync(target) && existsSync(`${target}.js`)) target = `${target}.js`
    if (!target.startsWith(`${resolve(consumer)}${sep}`) || !existsSync(target)) {
      missing.push(requested)
      response.writeHead(404).end()
      return
    }
    response.writeHead(200, {
      'content-type': ['.js', '.mjs'].includes(extname(target)) ? 'text/javascript' : 'text/html',
    }).end(readFileSync(target))
  })
  await new Promise<void>((done, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', done)
  })
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('browser fixture server has no TCP address')
  const chrome = existsSync('/usr/bin/google-chrome') ? realpathSync('/usr/bin/google-chrome') : undefined
  const browser = await chromium.launch({ headless: true, ...(chrome ? { executablePath: chrome } : {}) })
  try {
    const page = await browser.newPage()
    const errors: string[] = []
    page.on('pageerror', error => errors.push(error.message))
    page.on('console', message => { if (message.type() === 'error') errors.push(message.text()) })
    await page.goto(`http://127.0.0.1:${address.port}/`)
    try { await page.waitForFunction(() => '__mcpServerFixture' in globalThis) }
    catch (error) {
      throw new Error(`browser fixture did not initialize: ${errors.join(' | ')}; missing=${missing.join(',')}`, {
        cause: error,
      })
    }
    assertFixture(await page.evaluate(() => (
      globalThis as typeof globalThis & { __mcpServerFixture: unknown }
    ).__mcpServerFixture), 'browser')
  } finally {
    await browser.close()
    await new Promise<void>(done => server.close(() => done()))
  }
}

async function testWorker(consumer: string): Promise<void> {
  const port = await availablePort()
  const child = spawn(join(workspaceRoot, 'node_modules', '.bin', 'wrangler'), [
    'dev', '--config', 'wrangler.jsonc', '--ip', '127.0.0.1', '--port', String(port),
  ], { cwd: consumer, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] })
  let output = ''
  child.stdout?.on('data', chunk => { output = `${output}${String(chunk)}`.slice(-16_384) })
  child.stderr?.on('data', chunk => { output = `${output}${String(chunk)}`.slice(-16_384) })
  try {
    const response = await poll(`http://127.0.0.1:${port}`, child)
    assertFixture(await response.json(), 'worker')
  } catch (error) {
    throw new Error(`Worker packed fixture failed\n${output}`, { cause: error })
  } finally {
    await stop(child)
  }
}

function assertFixture(value: unknown, runtime: string): void {
  const result = value as Record<string, unknown>
  if (!result.inert || !result.discovered || !result.listed || !result.called
    || !result.requestBounded || !result.responseBounded || !result.aborted
    || result.buffer !== 'undefined' || result.process !== 'undefined') {
    throw new Error(`${runtime} fixture returned invalid evidence: ${JSON.stringify(result)}`)
  }
}

async function availablePort(): Promise<number> {
  const server = createServer()
  await new Promise<void>((done, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', done)
  })
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('could not allocate fixture port')
  await new Promise<void>(done => server.close(() => done()))
  return address.port
}

async function poll(url: string, child: ChildProcess): Promise<Response> {
  const deadline = Date.now() + 20_000
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`wrangler exited with ${child.exitCode}`)
    try {
      const response = await fetch(url)
      if (response.ok) return response
    } catch { /* still starting */ }
    await new Promise(done => setTimeout(done, 100))
  }
  throw new Error('wrangler did not become ready within 20 seconds')
}

async function stop(child: ChildProcess): Promise<void> {
  if (child.exitCode !== null) return
  child.kill('SIGTERM')
  await Promise.race([
    new Promise<void>(done => child.once('exit', () => done())),
    new Promise<void>(done => setTimeout(done, 5_000)),
  ])
  if (child.exitCode === null) child.kill('SIGKILL')
}
